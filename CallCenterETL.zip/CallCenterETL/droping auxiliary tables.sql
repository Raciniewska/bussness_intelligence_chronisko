USE auxiliary;
DROP TABLE swieta;
DROP TABLE wakacje;

USE master;

DROP DATABASE auxiliary;

GO
