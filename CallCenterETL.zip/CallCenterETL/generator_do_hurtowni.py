
minuta=0
pory_dnia=['od 0 do 8','od 9 do 12','od 13 do 15','od 16 do 20','od 21 do 23']
godzina=0

file = open("time.sql","w")
while godzina<24:
    minuta=0
    while minuta<60:
        file.write("insert into dbo.Czas (\"Godzina\",\"Minuta\", \"Pora_Dnia\") values (")
        file.write(str(godzina)+","+str(minuta)+",'")
        if godzina<=8:
            file.write(pory_dnia[0])
        elif godzina<=12:
            file.write(pory_dnia[1])
        elif godzina<=15:
            file.write(pory_dnia[2])
        elif godzina<=20:
            file.write(pory_dnia[3])
        elif godzina<=23:
            file.write(pory_dnia[4])
        file.write("');\n")
        minuta=minuta+1
    godzina=godzina+1
file.close()

