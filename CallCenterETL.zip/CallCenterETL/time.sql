INSERT INTO dbo.Czas
                  ([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 0, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 1, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 2, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 3, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 4, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 5, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 6, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 7, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 8, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 9, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 10, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 11, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 12, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 13, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 14, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 15, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 16, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 17, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 18, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 19, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 20, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 21, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 22, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 23, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 24, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 25, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 26, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 27, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 28, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 29, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 30, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 31, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 32, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 33, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 34, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 35, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 36, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 37, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 38, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 39, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 40, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 41, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 42, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 43, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 44, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 45, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 46, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 47, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 48, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 49, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 50, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 51, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 52, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 53, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 54, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 55, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 56, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 57, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 58, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (0, 59, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 0, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 1, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 2, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 3, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 4, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 5, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 6, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 7, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 8, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 9, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 10, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 11, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 12, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 13, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 14, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 15, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 16, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 17, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 18, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 19, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 20, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 21, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 22, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 23, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 24, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 25, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 26, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 27, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 28, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 29, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 30, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 31, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 32, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 33, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 34, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 35, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 36, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 37, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 38, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 39, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 40, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 41, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 42, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 43, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 44, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 45, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 46, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 47, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 48, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 49, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 50, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 51, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 52, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 53, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 54, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 55, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 56, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 57, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 58, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (1, 59, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 0, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 1, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 2, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 3, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 4, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 5, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 6, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 7, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 8, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 9, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 10, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 11, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 12, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 13, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 14, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 15, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 16, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 17, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 18, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 19, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 20, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 21, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 22, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 23, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 24, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 25, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 26, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 27, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 28, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 29, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 30, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 31, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 32, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 33, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 34, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 35, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 36, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 37, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 38, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 39, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 40, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 41, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 42, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 43, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 44, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 45, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 46, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 47, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 48, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 49, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 50, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 51, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 52, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 53, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 54, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 55, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 56, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 57, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 58, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (2, 59, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 0, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 1, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 2, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 3, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 4, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 5, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 6, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 7, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 8, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 9, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 10, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 11, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 12, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 13, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 14, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 15, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 16, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 17, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 18, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 19, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 20, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 21, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 22, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 23, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 24, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 25, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 26, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 27, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 28, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 29, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 30, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 31, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 32, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 33, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 34, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 35, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 36, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 37, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 38, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 39, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 40, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 41, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 42, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 43, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 44, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 45, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 46, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 47, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 48, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 49, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 50, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 51, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 52, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 53, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 54, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 55, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 56, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 57, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 58, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (3, 59, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 0, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 1, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 2, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 3, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 4, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 5, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 6, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 7, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 8, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 9, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 10, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 11, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 12, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 13, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 14, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 15, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 16, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 17, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 18, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 19, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 20, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 21, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 22, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 23, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 24, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 25, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 26, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 27, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 28, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 29, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 30, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 31, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 32, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 33, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 34, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 35, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 36, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 37, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 38, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 39, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 40, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 41, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 42, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 43, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 44, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 45, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 46, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 47, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 48, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 49, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 50, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 51, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 52, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 53, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 54, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 55, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 56, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 57, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 58, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (4, 59, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 0, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 1, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 2, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 3, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 4, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 5, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 6, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 7, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 8, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 9, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 10, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 11, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 12, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 13, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 14, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 15, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 16, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 17, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 18, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 19, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 20, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 21, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 22, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 23, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 24, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 25, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 26, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 27, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 28, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 29, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 30, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 31, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 32, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 33, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 34, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 35, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 36, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 37, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 38, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 39, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 40, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 41, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 42, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 43, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 44, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 45, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 46, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 47, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 48, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 49, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 50, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 51, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 52, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 53, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 54, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 55, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 56, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 57, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 58, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (5, 59, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 0, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 1, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 2, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 3, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 4, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 5, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 6, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 7, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 8, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 9, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 10, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 11, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 12, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 13, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 14, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 15, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 16, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 17, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 18, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 19, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 20, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 21, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 22, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 23, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 24, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 25, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 26, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 27, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 28, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 29, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 30, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 31, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 32, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 33, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 34, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 35, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 36, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 37, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 38, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 39, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 40, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 41, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 42, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 43, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 44, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 45, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 46, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 47, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 48, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 49, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 50, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 51, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 52, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 53, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 54, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 55, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 56, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 57, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 58, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (6, 59, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 0, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 1, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 2, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 3, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 4, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 5, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 6, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 7, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 8, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 9, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 10, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 11, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 12, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 13, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 14, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 15, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 16, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 17, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 18, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 19, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 20, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 21, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 22, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 23, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 24, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 25, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 26, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 27, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 28, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 29, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 30, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 31, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 32, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 33, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 34, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 35, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 36, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 37, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 38, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 39, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 40, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 41, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 42, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 43, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 44, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 45, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 46, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 47, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 48, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 49, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 50, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 51, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 52, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 53, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 54, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 55, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 56, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 57, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 58, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (7, 59, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 0, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 1, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 2, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 3, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 4, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 5, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 6, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 7, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 8, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 9, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 10, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 11, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 12, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 13, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 14, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 15, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 16, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 17, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 18, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 19, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 20, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 21, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 22, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 23, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 24, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 25, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 26, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 27, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 28, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 29, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 30, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 31, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 32, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 33, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 34, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 35, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 36, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 37, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 38, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 39, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 40, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 41, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 42, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 43, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 44, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 45, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 46, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 47, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 48, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 49, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 50, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 51, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 52, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 53, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 54, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 55, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 56, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 57, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 58, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (8, 59, 'od 0 do 8');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 0, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 1, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 2, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 3, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 4, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 5, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 6, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 7, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 8, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 9, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 10, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 11, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 12, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 13, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 14, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 15, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 16, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 17, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 18, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 19, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 20, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 21, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 22, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 23, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 24, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 25, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 26, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 27, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 28, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 29, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 30, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 31, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 32, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 33, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 34, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 35, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 36, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 37, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 38, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 39, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 40, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 41, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 42, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 43, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 44, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 45, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 46, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 47, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 48, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 49, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 50, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 51, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 52, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 53, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 54, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 55, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 56, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 57, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 58, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (9, 59, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 0, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 1, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 2, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 3, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 4, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 5, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 6, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 7, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 8, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 9, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 10, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 11, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 12, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 13, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 14, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 15, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 16, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 17, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 18, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 19, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 20, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 21, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 22, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 23, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 24, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 25, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 26, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 27, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 28, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 29, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 30, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 31, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 32, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 33, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 34, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 35, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 36, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 37, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 38, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 39, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 40, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 41, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 42, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 43, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 44, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 45, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 46, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 47, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 48, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 49, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 50, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 51, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 52, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 53, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 54, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 55, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 56, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 57, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 58, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (10, 59, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 0, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 1, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 2, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 3, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 4, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 5, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 6, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 7, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 8, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 9, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 10, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 11, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 12, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 13, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 14, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 15, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 16, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 17, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 18, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 19, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 20, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 21, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 22, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 23, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 24, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 25, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 26, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 27, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 28, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 29, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 30, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 31, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 32, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 33, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 34, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 35, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 36, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 37, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 38, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 39, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 40, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 41, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 42, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 43, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 44, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 45, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 46, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 47, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 48, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 49, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 50, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 51, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 52, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 53, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 54, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 55, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 56, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 57, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 58, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (11, 59, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 0, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 1, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 2, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 3, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 4, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 5, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 6, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 7, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 8, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 9, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 10, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 11, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 12, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 13, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 14, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 15, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 16, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 17, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 18, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 19, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 20, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 21, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 22, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 23, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 24, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 25, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 26, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 27, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 28, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 29, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 30, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 31, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 32, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 33, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 34, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 35, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 36, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 37, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 38, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 39, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 40, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 41, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 42, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 43, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 44, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 45, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 46, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 47, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 48, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 49, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 50, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 51, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 52, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 53, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 54, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 55, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 56, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 57, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 58, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (12, 59, 'od 9 do 12');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 0, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 1, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 2, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 3, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 4, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 5, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 6, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 7, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 8, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 9, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 10, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 11, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 12, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 13, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 14, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 15, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 16, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 17, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 18, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 19, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 20, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 21, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 22, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 23, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 24, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 25, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 26, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 27, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 28, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 29, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 30, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 31, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 32, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 33, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 34, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 35, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 36, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 37, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 38, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 39, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 40, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 41, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 42, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 43, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 44, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 45, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 46, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 47, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 48, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 49, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 50, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 51, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 52, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 53, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 54, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 55, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 56, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 57, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 58, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (13, 59, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 0, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 1, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 2, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 3, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 4, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 5, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 6, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 7, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 8, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 9, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 10, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 11, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 12, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 13, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 14, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 15, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 16, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 17, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 18, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 19, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 20, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 21, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 22, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 23, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 24, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 25, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 26, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 27, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 28, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 29, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 30, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 31, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 32, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 33, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 34, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 35, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 36, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 37, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 38, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 39, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 40, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 41, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 42, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 43, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 44, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 45, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 46, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 47, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 48, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 49, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 50, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 51, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 52, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 53, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 54, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 55, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 56, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 57, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 58, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (14, 59, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 0, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 1, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 2, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 3, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 4, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 5, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 6, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 7, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 8, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 9, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 10, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 11, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 12, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 13, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 14, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 15, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 16, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 17, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 18, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 19, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 20, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 21, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 22, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 23, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 24, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 25, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 26, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 27, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 28, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 29, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 30, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 31, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 32, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 33, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 34, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 35, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 36, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 37, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 38, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 39, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 40, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 41, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 42, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 43, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 44, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 45, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 46, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 47, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 48, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 49, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 50, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 51, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 52, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 53, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 54, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 55, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 56, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 57, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 58, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (15, 59, 'od 13 do 15');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 0, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 1, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 2, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 3, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 4, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 5, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 6, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 7, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 8, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 9, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 10, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 11, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 12, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 13, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 14, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 15, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 16, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 17, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 18, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 19, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 20, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 21, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 22, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 23, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 24, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 25, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 26, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 27, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 28, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 29, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 30, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 31, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 32, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 33, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 34, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 35, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 36, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 37, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 38, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 39, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 40, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 41, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 42, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 43, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 44, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 45, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 46, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 47, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 48, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 49, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 50, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 51, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 52, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 53, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 54, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 55, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 56, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 57, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 58, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (16, 59, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 0, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 1, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 2, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 3, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 4, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 5, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 6, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 7, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 8, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 9, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 10, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 11, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 12, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 13, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 14, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 15, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 16, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 17, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 18, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 19, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 20, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 21, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 22, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 23, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 24, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 25, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 26, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 27, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 28, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 29, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 30, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 31, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 32, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 33, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 34, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 35, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 36, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 37, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 38, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 39, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 40, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 41, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 42, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 43, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 44, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 45, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 46, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 47, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 48, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 49, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 50, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 51, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 52, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 53, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 54, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 55, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 56, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 57, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 58, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (17, 59, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 0, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 1, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 2, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 3, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 4, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 5, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 6, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 7, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 8, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 9, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 10, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 11, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 12, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 13, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 14, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 15, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 16, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 17, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 18, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 19, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 20, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 21, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 22, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 23, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 24, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 25, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 26, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 27, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 28, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 29, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 30, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 31, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 32, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 33, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 34, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 35, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 36, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 37, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 38, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 39, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 40, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 41, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 42, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 43, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 44, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 45, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 46, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 47, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 48, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 49, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 50, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 51, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 52, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 53, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 54, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 55, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 56, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 57, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 58, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (18, 59, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 0, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 1, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 2, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 3, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 4, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 5, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 6, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 7, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 8, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 9, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 10, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 11, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 12, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 13, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 14, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 15, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 16, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 17, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 18, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 19, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 20, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 21, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 22, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 23, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 24, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 25, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 26, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 27, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 28, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 29, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 30, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 31, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 32, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 33, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 34, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 35, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 36, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 37, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 38, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 39, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 40, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 41, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 42, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 43, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 44, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 45, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 46, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 47, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 48, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 49, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 50, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 51, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 52, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 53, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 54, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 55, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 56, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 57, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 58, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (19, 59, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 0, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 1, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 2, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 3, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 4, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 5, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 6, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 7, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 8, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 9, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 10, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 11, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 12, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 13, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 14, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 15, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 16, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 17, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 18, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 19, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 20, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 21, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 22, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 23, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 24, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 25, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 26, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 27, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 28, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 29, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 30, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 31, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 32, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 33, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 34, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 35, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 36, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 37, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 38, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 39, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 40, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 41, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 42, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 43, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 44, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 45, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 46, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 47, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 48, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 49, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 50, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 51, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 52, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 53, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 54, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 55, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 56, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 57, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 58, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (20, 59, 'od 16 do 20');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 0, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 1, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 2, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 3, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 4, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 5, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 6, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 7, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 8, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 9, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 10, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 11, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 12, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 13, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 14, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 15, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 16, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 17, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 18, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 19, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 20, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 21, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 22, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 23, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 24, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 25, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 26, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 27, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 28, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 29, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 30, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 31, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 32, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 33, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 34, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 35, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 36, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 37, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 38, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 39, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 40, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 41, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 42, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 43, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 44, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 45, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 46, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 47, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 48, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 49, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 50, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 51, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 52, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 53, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 54, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 55, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 56, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 57, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 58, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (21, 59, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 0, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 1, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 2, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 3, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 4, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 5, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 6, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 7, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 8, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 9, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 10, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 11, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 12, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 13, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 14, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 15, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 16, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 17, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 18, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 19, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 20, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 21, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 22, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 23, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 24, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 25, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 26, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 27, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 28, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 29, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 30, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 31, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 32, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 33, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 34, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 35, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 36, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 37, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 38, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 39, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 40, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 41, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 42, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 43, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 44, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 45, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 46, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 47, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 48, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 49, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 50, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 51, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 52, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 53, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 54, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 55, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 56, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 57, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 58, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (22, 59, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 0, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 1, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 2, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 3, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 4, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 5, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 6, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 7, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 8, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 9, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 10, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 11, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 12, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 13, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 14, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 15, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 16, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 17, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 18, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 19, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 20, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 21, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 22, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 23, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 24, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 25, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 26, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 27, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 28, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 29, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 30, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 31, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 32, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 33, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 34, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 35, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 36, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 37, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 38, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 39, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 40, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 41, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 42, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 43, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 44, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 45, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 46, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 47, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 48, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 49, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 50, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 51, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 52, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 53, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 54, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 55, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 56, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 57, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 58, 'od 21 do 23');
                      INSERT  
                      INTO        dbo.Czas([Godzina], [Minuta], [Pora_Dnia])
VALUES (23, 59, 'od 21 do 23');
